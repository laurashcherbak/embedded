#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define LED_PIN PB5 // buildin led
/*
ISR(TIMER0_OVF_vect) 
{
}
void TIMER0_OVF_vect (void) __attribute__ ((signal, used, externally_visible));
void TIMER0_OVF_vect (void) 
{
}*/
//*((volatile uint8_t *)(0x05) + 0x20) = 54;
uint8_t dl = 0, state = 0;
uint8_t data = 1;


void key_handler(void)
{
  // state ^=1;
static uint8_t d=0;

  d<<=1; d|=1;
  if(d>=255) { d=1; }
   PORTD = d;
}

void scan_key(void)
{
  static uint8_t shreg;

  shreg <<= 1; // shreg = shreg + shreg; , shreg = shreg * 2;
  if((PINB & (1<<PB1)) != 0) {
    shreg |= 1;
  }

  if((shreg & 0x07) == 0x04) {
    key_handler();
  }
}



//-----------------------------------------------------------
int main(void)
{
  DDRD = 0xFF;

    for(;;) 
    {

      //--------------------------
      // if(++dl > 20) {
      //  dl =0;
      //  PORTD = data;
      //  if(state==0) {
      //     data <<= 1;
      //  } else {
      //     data >>= 1;
      //  }

      // if(data == 0) {
      //   if(state == 0) {
      //     data = 1;
      //   } else {
      //     data = 128;
      //   }

      //   //st ^= 1;
      // }
      // }

      //------------------------
      
      scan_key();
      _delay_ms(10);
    }
  return 0;
}